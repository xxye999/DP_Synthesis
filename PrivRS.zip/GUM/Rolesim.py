import networkx as nx
import GUM.generate_graph

# graph = generate_graph.generate_graph()

def initialize_rolesim(graph):
    rolesim = {}
    # 遍历图中的所有节点对
    for u in graph.nodes():
        for v in graph.nodes():
            if u != v:
                # 获取节点u和v的度数
                degree_u = graph.degree(u)
                degree_v = graph.degree(v)
                # 判断度数是否相等并赋予初始值
                if degree_u == degree_v:
                    rolesim[(u, v)] = 1
                else:
                    rolesim[(u, v)] = 0
    return rolesim

# beta = 0.1
# convergence_threshold = 0.01
def compute_rolesim(graph, beta, convergence_threshold):
    # 初始化rolesim
    init_rolesim = initialize_rolesim(graph)

    R_previous = init_rolesim.copy()
    R_current = {}

    while True:
        # 复制上一次迭代的RoleSim值
        R_current = R_previous.copy()

        # 遍历图中的所有节点对，计算新一轮的RoleSim值
        for u1 in graph.nodes():
            for v1 in graph.nodes():
                if u1 != v1:
                    # 获取节点u和v的邻居节点
                    neighbors_u = set(graph[u1])
                    neighbors_v = set(graph[v1])

                    # # 计算匹配M(u, v)
                    # matching = set()
                    # for x in neighbors_u:
                    #     for y in neighbors_v:
                    #         if x not in [pair[0] for pair in matching] and y not in [pair[1] for pair in matching]:
                    #             matching.add((x, y))
                    #
                    # # 计算M(u, v)的大小
                    # matching_size = len(matching)

                    # 计算新的RoleSim值
                    graph_weight = nx.Graph()
                    graph_weight.add_nodes_from([f'u_{u}' for u in neighbors_u])
                    graph_weight.add_nodes_from([f'v_{v}' for v in neighbors_v])
                    for u2 in neighbors_u:
                        for v2 in neighbors_v:
                            if u2 == v2:
                                graph_weight.add_edge(f'u_{u2}', f'v_{v2}', weight=1)
                            if u2 != v2:
                                graph_weight.add_edge(f'u_{u2}', f'v_{v2}', weight=R_current[(u2, v2)])

                    matching = nx.max_weight_matching(graph_weight)
                    max_weight = sum(graph_weight[u][v]['weight'] for u, v in matching)

                    # R_current[(u1, v1)] = (1 - beta) * max_weight / max(len(neighbors_u), len(neighbors_v)) + beta
                    R_current[(u1, v1)] = (1 - beta) * max_weight / max(len(neighbors_u), len(neighbors_v)) + beta
        # 检查RoleSim值是否收敛
        convergence = True
        for pair in R_current.keys():
            if abs(R_current[pair] - R_previous[pair]) > convergence_threshold * R_previous[pair]:
                convergence = False
                break

        # 如果RoleSim值收敛，则退出循环
        if convergence:
            break

        # 更新上一次迭代的RoleSim值
        R_previous = R_current.copy()

    return R_current


