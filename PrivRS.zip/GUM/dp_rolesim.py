import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from GUM.domain import Domain
import numpy as np
from GUM.generate_graph import AttributeGraphConstructor
import GUM.Rolesim
from GUM.marg_combine import MargCombine
from dpsyn_clean.lib_composition.advanced_composition import AdvancedComposition
class DP_Rolesim:
    def __init__(self,original_dataset,epsilon,args):
        self.original_dataset = original_dataset
        self.epsilon = epsilon
        self.args = args
        # self.attrGraph = nx.Graph()
        # self.R_rolesim = {}
        self.construct_graph()
        self.rolesim()
        self.select_marginal()
        self.postprocessing()
        self.synthesize_records()

    def construct_graph(self):
        # path = 'temp_data/processed_data/' + self.dataname
        # self.data = pd.read_csv(path, sep=',')
        self.data = self.original_dataset.df
        attr = self.data.columns
        self.domain = self.original_dataset.domain
        # shape = [len(set(self.data.values[:, i])) for i in range(self.data.shape[1])]
        # self.domain = Domain(attr,shape)
        data_name = self.args["dataset_name"]
        if data_name == "adult":
            # threshold = 1000
            threshold = 1e7
        elif data_name == "bank":
            # threshold = 1000
            threshold = 1e7
        elif data_name == "mushroom":
            threshold = 1e7
        elif data_name == "salaries":
            threshold = 1e5
        attributeGraph = AttributeGraphConstructor(self.data,self.domain, self.epsilon, threshold)
        self.attrGraph = attributeGraph.construct_attribute_graph()


    def rolesim(self):
        # R_rolesim = {}
        beta = 0.1
        convergence_threshold = 0.01
        #添加噪声
        num_records = self.original_dataset.df.shape[0]
        delta = 1.0 / num_records ** 2
        sensitivity = 1
        composition = AdvancedComposition()
        sigma = composition.gauss_zcdp(self.epsilon/2, delta, sensitivity, 1)
        noise = sigma / num_records / 2
        R_rolesim = GUM.Rolesim.compute_rolesim(self.attrGraph, beta, convergence_threshold)
        for key, value in R_rolesim.items():
            R_rolesim[key] = value + np.random.normal(scale=noise)
        #降序排列
        self.R_rolesim = dict(sorted(R_rolesim.items(), key=lambda item: -item[1]))
####################################################
        # pos = nx.spring_layout(self.attrGraph)  # 为节点选择一个布局
        # nx.draw(self.attrGraph, pos, with_labels=True)  # 绘制节点和标签
        # # 绘制边权重
        # labels = nx.get_edge_attributes(self.attrGraph, 'weight')
        # nx.draw_networkx_edge_labels(self.attrGraph, pos, edge_labels=labels)
        # # 显示图形
        # plt.show()
        # print(self.R_rolesim)

    def select_marginal(self):
        unique_R_rolesim = {}
        select_marginals = []
        # phi = 0.8
        data_name = self.args["dataset_name"]
        if data_name == "adult":
            phi = 0.4
        elif data_name == "bank":
            phi = 0.4
        elif data_name == "mushroom":
            # phi = 0.9
            phi = 0.9
        elif data_name == "salaries":
            phi = 0.5
        for key, value in self.R_rolesim.items():
            sorted_key = tuple(sorted(key))
            unique_R_rolesim[sorted_key] = value
        for key in unique_R_rolesim.keys():
            attr1 = key[0]
            attr2 = key[1]
            attr1_size = self.domain.project(attr1).size()
            attr2_size = self.domain.project(attr2).size()
            if unique_R_rolesim[key] > min(abs(attr1_size - 1), abs(attr2_size - 1)) * phi ** 2 / 2:
                select_marginals.append(key)
        self.marginals = select_marginals

        # top_R_rolesim = dict(list(unique_R_rolesim.items())[:40])
        # self.marginals = list(top_R_rolesim.keys())

        self.marginals = self.combine_pairs(self.marginals)
        print(self.marginals)

    def postprocessing(self):
        pass

    def synthesize_records(self):
        # total_epsilon = self.epsilon * 0.1
        # views_epsilon = self.epsilon * 0.1
        # Marginals(self.marginal, self.dataname, self.data, self.domain, total_epsilon, views_epsilon)
        pass

    def combine_pairs(self, marginals):
        # self.logger.info("%s marginals before combining" % (len(marginals)))
        data_name = self.args["dataset_name"]
        if data_name == "adult":
            # threshold = 5000
            threshold = 5000
        elif data_name == "bank":
            threshold = 5000
        elif data_name == "mushroom":
            # threshold = 3000
            threshold = 5000
        elif data_name == "salaries":
            threshold = 5000
        marg_combine = MargCombine(self.domain, marginals)
        marginals = marg_combine.determine_marginals(threshold,enable=True)

        # self.logger.info("%s marginals after combining" % (len(marginals)))

        return marginals
if __name__ == '__main__':
    pass