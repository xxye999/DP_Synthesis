import numpy as np
import networkx as nx
from itertools import combinations
import random
import pandas as pd
import matplotlib.pyplot as plt
from GUM.domain import Domain
from dpsyn_clean.lib_composition.advanced_composition import AdvancedComposition

class AttributeGraphConstructor:
    def __init__(self, data,domain, epsilon, threshold):
        self.data = data
        self.domain = domain
        self.num_records = self.data.shape[0]
        self.epsilon = epsilon
        self.threshold = threshold
        self.maximal_cliques = None
        self.noisy_r_scores = {}

        self.delta = 1.0 / self.num_records ** 2
        # self.R_score_sensitivity = 2
        # self.sensitivity = 2 / self.num_records
        self.sensitivity = 2
        noise_num = len(list(combinations(self.data.columns, 2)))
        # epsilon = self.epsilon / noise_num
        composition = AdvancedComposition()
        # epsilon = 0.2, delta = 1/n^2, marg_add_sensitivity = 1.0
        sigma = composition.gauss_zcdp(self.epsilon/2, self.delta,self.sensitivity , 1)
        self.r_score_noise = sigma / self.num_records / 2

    def construct_attribute_graph(self):
        noisy_r_scores = {}
        edges = []
        attribute_pairs = list(combinations(self.data.columns, 2))
        for pair in attribute_pairs:  #pair is tuple
            r_score = self.calculate_r_score(pair)
            edges.append((pair[0], pair[1], r_score))
        edges.sort(key=lambda x: x[2], reverse=True)

        graph = nx.Graph()
        graph.add_nodes_from(self.data.columns)

        for edge in edges:
            attribute1, attribute2, r_score = edge
            graph.add_edge(attribute1, attribute2)
            noisy_r_scores[(attribute1, attribute2)] = r_score
            tri_graph = graph.copy()
            if not nx.is_chordal(tri_graph):
                tri_graph = self.triangulate(tri_graph)

            maximal_cliques = list(nx.find_cliques(tri_graph))
            if not (self.check_clique_domain_size(maximal_cliques)):
                graph.remove_edge(attribute1, attribute2)
                noisy_r_scores.pop((attribute1, attribute2))

        self.maximal_cliques = list(nx.find_cliques(graph))
        self.noisy_r_scores = noisy_r_scores

        # return self.maximal_cliques, self.noisy_r_scores
        return graph

    def calculate_r_score(self, index_list):
        num_records = self.data.shape[0]
        # index_list = tuple(sorted(index_list))
        domain = self.domain.project(index_list)
        bins = domain.edge()
        # size = domain.size()
        index_list_num = [self.data.columns.get_loc(col) for col in index_list]
        histogram1, _ = np.histogramdd(self.data.values[:, index_list_num], bins=bins)
        # pairwise_probability = histogram1 / num_records
        pairwise_probability = histogram1

        attr1_domain = domain.project([index_list[0]])
        attr1_bins = attr1_domain.edge()
        attr1_num = self.data.columns.get_loc(index_list[0])
        histogram2, _ = np.histogramdd(self.data.values[:, attr1_num], bins=attr1_bins)
        # attr1_probability = histogram2 / num_records
        attr1_probability = histogram2

        attr2_domain = domain.project([index_list[1]])
        attr2_bins = attr2_domain.edge()
        attr2_num = self.data.columns.get_loc(index_list[1])
        histogram3, _ = np.histogramdd(self.data.values[:, attr2_num], bins=attr2_bins)
        # attr2_probability = histogram3 / num_records
        attr2_probability = histogram3
        (a, b) = pairwise_probability.shape
        product_probability = np.kron(attr1_probability, attr2_probability) / num_records
        product_probability = product_probability.reshape(a, b)

        # print("atttr1, attr2:", index_list, np.abs(pairwise_probability - product_probability))
        temp = np.abs(pairwise_probability - product_probability)
        r_score = np.sum(temp) / 2 / num_records
        r_score = r_score + np.random.normal(scale=self.r_score_noise)
        print("r_score:", r_score)

        return r_score

    def triangulate(self,graph):
        # print("****************this is triangulate**************")
        edges = set()
        G = nx.Graph(graph)

        nodes = sorted(graph.degree(), key=lambda x: x[1])
        for node, degree in nodes:
            local_complete_edges = set(combinations(G.neighbors(node), 2))
            edges |= local_complete_edges
            '''
            G.add_edges_from(local_complete_edges)
            G.remove_node(node)
            '''
        triangulated_graph = nx.Graph(graph)
        triangulated_graph.add_edges_from(edges)

        return triangulated_graph

    def check_clique_domain_size(self,maximal_cliques):
        for clique in maximal_cliques:
            temp_size = self.domain.project(clique).size()
            # if temp_size > self.config['max_clique_size'] or len(clique) > 15:
            if temp_size > self.threshold:
                return False
        return True



if __name__ == '__main__':
    path = "Database/adult.csv"
    data = pd.read_csv(path, sep=',')
    attr = data.columns
    shape = [len(set(data.values[:, i])) for i in range(data.shape[1])]
    domain = Domain(attr, shape)
    attGraph = AttributeGraphConstructor(data,domain, 1, 1000)
    attgraph = attGraph.construct_attribute_graph()

    pos = nx.spring_layout(attgraph)  # 为节点选择一个布局
    nx.draw(attgraph, pos, with_labels=True)  # 绘制节点和标签
    # 绘制边权重
    labels = nx.get_edge_attributes(attgraph, 'weight')
    nx.draw_networkx_edge_labels(attgraph, pos, edge_labels=labels)
    # 显示图形
    plt.show()