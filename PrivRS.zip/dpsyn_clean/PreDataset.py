from lib_dataset.dataset import Dataset
import config
from parameter_parser import parameter_parser
import pickle


def main(args):
    # config the logger
    dataset = Dataset.load(config.PROCESSED_DATA_PATH + args['dataset_name'], config.PROCESSED_DATA_PATH + args['domain_name'])
    synthesized_records_name = args['dataset_name']
    synthesized_records_file = config.RAW_DATA_PATH + synthesized_records_name
    pickle.dump((dataset.df, dataset.domain), open(synthesized_records_file + '.pkl', 'wb'))
    (dt_df, dt_domain) = pickle.load(open(synthesized_records_file + '.pkl', 'rb'))
    print(dt_df)
    print(dt_domain)


if __name__ == "__main__":
    args = parameter_parser()

    main(args)