# path related constant
RAW_DATA_PATH = "temp_data/raw_data/"
PROCESSED_DATA_PATH = "temp_data/processed_data/"
SYNTHESIZED_RECORDS_PATH = "temp_data/synthesized_records/DP_Rolesim_"
MARGINAL_PATH = "temp_data/marginal/"
DEPENDENCY_PATH = 'temp_data/dependency/'

ALL_PATH = [RAW_DATA_PATH, PROCESSED_DATA_PATH, SYNTHESIZED_RECORDS_PATH, MARGINAL_PATH, DEPENDENCY_PATH]

