import copy
import logging
import datetime

from dpsyn_clean.lib_attrs.attr_recode import AttrRecord
from dpsyn_clean.lib_view.marg_select import MarginalSelection
from dpsyn_clean.lib_dataset.data_store import DataStore
from dpsyn_clean.lib_composition.advanced_composition import AdvancedComposition

from GUM.dp_rolesim import DP_Rolesim
class Exp:
    def __init__(self, args):
        self.logger = logging.getLogger("exp")

        self.start_time = datetime.datetime.now()
        self.args = args

        self.epsilon = self.args['epsilon']  # epsilon = 2.0
        self.dataset_name = args["dataset_name"]

        ########################################### main proceedure ###########################################
        # load dataset
        # 生成合成数据的存放文件夹
        self.data_store = DataStore(self.args)
        self.load_data()
        self.logger.info("original dataset domain: %e" % (self.original_dataset.domain.size(),))

        self.num_records = self.original_dataset.df.shape[0]  # 数据条数n
        self.num_attributes = self.original_dataset.df.shape[1]  # 属性数量d
        self.delta = 1.0 / self.num_records ** 2  # delta = 1/n^2

        self.privacy_budget_allocation()  # 隐私预算分配(depend_epsilon, remain_epsilon = 0.2, 1.8)
        self.remain_rho = self._calculate_rho(self.remain_epsilon)  # 约0.036
        # self.marginals = self.select_marginals(self.original_dataset)
        dp_rolesim = DP_Rolesim(self.original_dataset,self.depend_epsilon,self.args)
        self.marginals = dp_rolesim.marginals
        self.data_store.save_marginal(self.marginals)
        # self.marginals = [("marital-status", "sex", "income>50K"), ("relationship", "education", "hours-per-week"), ("education-num", "relationship"), ("age", "occupation"), ("race", "income>50K")]
        # self.marginals = [("occupation", "race", "sex", "capital-loss"), ("relationship", "native-country"), ("capital-gain", "capital-loss"), ("education", "income>50K"), ("workclass", "relationship"), ("education-num", "marital-status", "race"), ("age", "race")]
        # self.marginals = [("fnlwgt", "education-num", "race"), ("relationship", "education", "sex", "hours-per-week"), ("marital-status", "occupation", "sex")]

        # remain_epsilon = 1.8, len(self.marginals) = 11 + self.num_attributes = 15 ==>26
        self.gauss_sigma = self._calculate_sigma(self.remain_epsilon, len(self.marginals) + self.num_attributes)
        # gauss_sigma 约等于 18.93083
        self.attr_recode = self.recode_attrs(self.gauss_sigma)  # 记录每条属性的记录（重新编码）

        self.logger.info('rho: %s | sigma: %s' % (self.remain_rho, self.gauss_sigma))

    ############################## preprocess ###########################################
    def load_data(self):
        self.logger.info("loading dataset %s" % (self.dataset_name,))
        #original_dataset为Dataset类
        self.original_dataset = self.data_store.load_processed_data()

    def privacy_budget_allocation(self):
        # depend_epsilon_ratio = 0.1
        self.depend_epsilon = self.epsilon * self.args['depend_epsilon_ratio']  # depend_epsilon = 0.2
        self.remain_epsilon = self.epsilon - self.depend_epsilon  # remain_epsilon = 2.0 - 0.2 = 1.8

        self.logger.info(
            'privacy budget allocation: marginal %s | synthesize %s' % (self.depend_epsilon, self.remain_epsilon))

    def select_marginals(self, dataset):
        if self.args['is_cal_marginals']:
            self.logger.info("selecting marginals")

            select_args = copy.deepcopy(self.args)
            select_args['total_epsilon'] = self.epsilon
            select_args['depend_epsilon'] = self.depend_epsilon
            select_args['remain_rho'] = self.remain_rho
            select_args['threshold'] = 5000
            # adult 5000


            marginal_selection = MarginalSelection(dataset, select_args)
            marginals = marginal_selection.select_marginals()
            self.data_store.save_marginal(marginals)
        else:
            marginals = self.data_store.load_marginal()

        return marginals

    def recode_attrs(self, sigma):
        self.logger.info("recoding attrs")

        # sigma = self._calculate_sigma(self.recode_epsilon, self.num_attributes)
        # sigma约等于18.930
        attr_recode = AttrRecord(self.original_dataset)
        attr_recode.recode(sigma)

        return attr_recode

    def _calculate_rho(self, epsilon):
        composition = AdvancedComposition()
        # epsilon = 1.8, delta = 1/n^2, marg_add_sensitivity = 1.0
        sigma = composition.gauss_zcdp(epsilon, self.delta, self.args['marg_add_sensitivity'], 1)
        # sigma 约等于

        return (self.args['marg_add_sensitivity'] ** 2 / (2.0 * sigma ** 2))  # 约0.036

    def _calculate_sigma(self, epsilon, num_views):
        composition = AdvancedComposition()

        # epsilon = 1.8, delta = 1/n^2, marg_add_sensitivity = 1.0, num_views = 26
        # 返回值约为18.930
        return composition.gauss_zcdp(epsilon, self.delta, self.args['marg_add_sensitivity'], num_views)
