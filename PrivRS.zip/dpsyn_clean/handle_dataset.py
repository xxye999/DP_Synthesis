import json
import os
import pickle
from typing import Tuple, Dict

import numpy as np
import pandas as pd
import yaml


def main():
    priv_pikcle_path = 'D:/Project/dpsyn_clean_fixed/dpsyn_clean/temp_data/raw_data/preprocessed_priv_deaths.pkl'
    [private_data, encode_mapping] = pickle.load(open(priv_pikcle_path, 'rb'))

    new_private_data = pd.DataFrame(private_data)
    new_private_data.to_csv('D:/Project/dpsyn_clean_fixed/dpsyn_clean/temp_data/processed_data/accidential_drug_deaths.csv')
    #new_encode =
    decode_mapping = {}
    print(encode_mapping)
    for attr, encode_mapping in encode_mapping.items():
        decode_mapping[attr] = sorted(encode_mapping, key=encode_mapping.get)
    print(decode_mapping)
    domain = {}
    for i, key in decode_mapping.items():
        print(i)
        print(key)
    #domain = {"Date": 9, "Age": 9, "Sex": 2, "Race": 7, "Residence State": 11, "Death County": 9, "Location": 7, "Location if Other": 10, "Injury County": 15, "Injury State": 3, "Heroin": 2, "Cocaine": 2, "Fentanyl": 2, "Fentanyl Analogue": 2, "Oxycodone": 2, "Oxymorphone": 2, "Ethanol": 2, "Hydrocodone": 2, "Benzodiazepine": 2, "Methadone": 2, "Amphet": 2, "Tramad": 2, "Morphine (Not Heroin)": 2, "Hydromorphone": 2, "Xylazine": 2, "Opiate NOS": 2, "Any Opioid": 2, "CardioCondition": 2, "RespiratoryCondition": 2, "ObesityCondition": 2, "DiabetesCondition": 2}

    '''
    with open(CONFIG_DATA, 'r', encoding="utf-8") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
    self.config = config
    print("------------------------> config yaml file loaded in DataLoader, config file: ", CONFIG_DATA)

    # which include parameters for several runs and data schema
    with open(PARAMS, 'r', encoding="utf-8") as f:
        parameter_spec = json.load(f)
        self.general_schema = parameter_spec['schema']
    print("------------------------> parameter file loaded in DataLoader, parameter file: ", PARAMS)

    # we use pickle to store the objects in files as binary flow
    priv_pickle_path = PICKLE_DIRECTORY / f"preprocessed_priv_{PRIV_DATA_NAME}.pkl"
    [self.private_data, self.encode_mapping] = pickle.load(open(priv_pickle_path, 'rb'))
    for attr, encode_mapping in self.encode_mapping.items():
        self.decode_mapping[attr] = sorted(encode_mapping, key=encode_mapping.get)
    '''
if __name__ == "__main__":
    main()