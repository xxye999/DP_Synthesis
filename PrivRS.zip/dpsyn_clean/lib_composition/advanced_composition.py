import math


class AdvancedComposition:
    def __init__(self):
        pass

    def gauss_zcdp(self, epsilon, delta, sensitivity, k):
        # epsilon = 1.8, delta = 1/n^2, sensitivity = 1.0, k = 1
        # epsilon = 1.8, delta = 1/n^2, sensitivity = 1.0, k = 26
        tmp_var = 2 * k * sensitivity ** 2 * math.log(1 / delta)
        # tmp_var = 2 * log(n^2) 约等于 14.632
        # tmp_var = 2 * 26 * log(n^2) 约等于 484.156

        sigma = (math.sqrt(tmp_var) + math.sqrt(tmp_var + 2 * k * sensitivity ** 2 * epsilon)) / (2 * epsilon)
        # sigma 约等于 5.004
        # sigma 约等于 28.680

        return sigma
