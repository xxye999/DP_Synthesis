import json
import pickle
import os

from dpsyn_clean import config
from dpsyn_clean.lib_dataset.dataset import Dataset

#生成合成数据的存放文件夹
class DataStore:
    def __init__(self, args):
        self.args = args

        self.determine_data_path()
        self.generate_folder()

    def determine_data_path(self):
        synthesized_records_name = '_'.join((self.args['dataset_name'], str(self.args['epsilon'])))
        marginal_name = '_'.join((self.args['dataset_name'], str(self.args['epsilon'])))

        self.synthesized_records_file = config.SYNTHESIZED_RECORDS_PATH + synthesized_records_name
        self.marginal_file = config.MARGINAL_PATH + marginal_name

    def generate_folder(self):
        for path in config.ALL_PATH:
            if not os.path.exists(path):
                os.makedirs(path)

    def load_processed_data(self):
        #    (dt_df, dt_domain) = pickle.load(open("D:/DifferentialPrivacy/code/dpsyn_clean/dpsyn_clean/temp_data/raw_data/adult.csv.pkl", 'rb'))
        #    dt = Dataset(dt_df, dt_domain)
        #    return dt
        return Dataset.load(open(config.PROCESSED_DATA_PATH + self.args['dataset_name'] + '.csv', 'r'),
                            config.PROCESSED_DATA_PATH + self.args['domain_name'] + '.json')
        #      return pickle.load(open('D:/DifferentialPrivacy/code/dpsyn_clean/dpsyn_clean/temp_data/raw_data/preprocessed_priv_deaths.pkl', 'rb'))
        #      return pickle.load(open(config.PROCESSED_DATA_PATH + self.args['dataset_name'], 'rb'))

    def save_synthesized_records(self, records):
        #     Dataset.to_csv(self, records, open(self.synthesized_records_file, 'w'), index=True)
        pickle.dump(records, open(self.synthesized_records_file + '.pkl', 'wb'))

    #  将records数据(Dataset)类中的df, domain数据分开存储
    def save_synthesized_records_data(self, records_data):
        data_num = records_data.shape[0]
        Dataset.to_csv(self, records_data,
                       open(self.synthesized_records_file + '.csv', 'w', encoding='utf-8', newline=''))

    def save_synthesized_records_domain(self, records_domain):
        json.dump(records_domain, open(self.synthesized_records_file + '.json', 'w'))
        #   new_records_domain = pd.DataFrame(records_domain)
        #   new_records_domain.to_json(open(self.synthesized_records_file + '.json', 'w'))
        #   with open(self.synthesized_records_file + '.json', 'wb') as save_domain:
        #   json.dump(records_domain, save_domain)

    def read_synthesized_records(self):
        return pickle.load(open(self.synthesized_records_file + '.pkl', 'rb'))

    def save_marginal(self, marginals):
        Dataset.to_csv(self, marginals, self.marginal_file + '.csv', index=True)
        # pickle.dump(marginals, open(self.marginal_file, 'wb'))

    def load_marginal(self):
        return Dataset.csv_read(self, open(self.marginal_file, 'r'))
        # return pickle.load(open(self.marginal_file, 'rb'))
