import logging
import time

from dpsyn_clean.exp_dpsyn_gum import ExpDPSynGUM
from parameter_parser import parameter_parser


def config_logger():
    # create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s:%(asctime)s: - %(name)s - : %(message)s')

    # create console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)


def main(args):
    # config the logger
    start_time = time.time()
    config_logger()
    # epsilon_list = [0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0]
    epsilon_list = [0.2]
    for epsilon in epsilon_list:
        args['epsilon'] = epsilon
        ExpDPSynGUM(args)
    end_time = time.time()
    print("all_time:", end_time - start_time)

if __name__ == "__main__":
    args = parameter_parser()

    main(args)
